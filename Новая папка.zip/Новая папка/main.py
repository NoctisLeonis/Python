import tkinter as tk
from tkinter import scrolledtext, filedialog, messagebox
import sqlite3
import os
import random

from datetime import datetime
from weather_module import WeatherManager  

class SimpleNeuralNetwork:
    def __init__(self, db_name="knowledge.db"):
        """Инициализация базы знаний чат-бота."""
        self.db_name = db_name
        self.init_db()

    def init_db(self):
        """Инициализация базы данных для чат-бота."""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS knowledge (
                    question TEXT PRIMARY KEY,
                    answer TEXT NOT NULL
                )
            ''')
            cursor.execute("SELECT COUNT(*) FROM knowledge")
            if cursor.fetchone()[0] == 0:
                initial_data = [
                    ("привет", "Привет! Как твои дела?"),
                    ("как дела?", "У меня всё отлично, спасибо!"),
                    ("пока", "До свидания! Заходи ещё!"),
                    ("кто ты?", "Я умный помощник с чат-ботом, музыкой и погодой!"),
                    ("включи музыку", "Сейчас включу случайную музыку из папки!"),
                    ("какая погода?", "Сейчас проверю погоду!"),
                    ("обнови погоду", "Попробую обновить данные о погоде."),
                ]
                cursor.executemany(
                    "INSERT INTO knowledge (question, answer) VALUES (?, ?)",
                    initial_data
                )
            conn.commit()

    def respond(self, message):
        """Ответ на сообщение пользователя.
        Args:
            message (str): Сообщение от пользователя.
        Returns:
            str: Ответ чат-бота.
        """
        message = message.lower().strip()
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT answer FROM knowledge WHERE question = ?",
                (message,)
            )
            result = cursor.fetchone()
            return result[0] if result else "Я не понимаю. Спроси что-нибудь другое."

class MusicPlayer:
    def __init__(self):
        """Инициализация проигрывателя музыки."""
        pygame.mixer.init()
        self.music_folder = ""
        self.music_files = []

    def set_music_folder(self, folder_path):
        """Установка папки с музыкой.
        Args:
            folder_path (str): Путь к папке с музыкой.
        Returns:
            bool: True, если папка существует и содержит музыкальные файлы.
        """
        if os.path.isdir(folder_path):
            self.music_folder = folder_path
            self.music_files = [
                os.path.join(folder_path, f)
                for f in os.listdir(folder_path)
                if f.endswith(('.mp3', '.wav', '.ogg'))
            ]
            return True
        return False

    def play_random(self):
        """Воспроизведение случайного трека.
        Returns:
            bool: True, если трек воспроизведён успешно.
        """
        if not self.music_files:
            return False
        track = random.choice(self.music_files)
        pygame.mixer.music.load(track)
        pygame.mixer.music.play()
        return True

class ChatApp:
    def __init__(self, root):
        """Инициализация приложения.
        Args:
            root (tk.Tk): Корневое окно Tkinter.
        """
        self.root = root
        self.root.title("Умный помощник")
        self.root.geometry("600x500")

        self.neural_network = SimpleNeuralNetwork()
        self.music_player = MusicPlayer()
        self.weather_manager = WeatherManager(city="Moscow")  # Модуль погоды

        self.chat_history = scrolledtext.ScrolledText(root, state='disabled')
        self.chat_history.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        self.input_field = tk.Entry(root)
        self.input_field.pack(padx=10, pady=5, fill=tk.X)
        self.input_field.bind("<Return>", self.send_message)

        self.select_folder_button = tk.Button(
            root, text="Выбрать папку с музыкой", command=self.select_music_folder
        )
        self.select_folder_button.pack(pady=5)

    def select_music_folder(self):
        """Выбор папки с музыкой."""
        folder_path = filedialog.askdirectory(title="Выберите папку с музыкой")
        if folder_path:
            if self.music_player.set_music_folder(folder_path):
                messagebox.showinfo("Успех", "Папка с музыкой выбрана!")
            else:
                messagebox.showerror("Ошибка", "Выбранная папка не существует.")

    def send_message(self, event):
        """Обработка сообщений от пользователя."""
        user_message = self.input_field.get()
        self.input_field.delete(0, tk.END)

        self.chat_history.config(state='normal')
        self.chat_history.insert(tk.END, f"Вы: {user_message}\n")

        if "обнови погоду" in user_message:
            self.chat_history.insert(tk.END, "Бот: Пробую обновить данные о погоде...\n")
            if self.weather_manager.fetch_weather():
                self.chat_history.insert(tk.END, "Бот: Данные о погоде успешно обновлены!\n\n")
            else:
                self.chat_history.insert(tk.END, "Бот: Не удалось обновить данные о погоде. Проверьте интернет.\n\n")

        elif "какая погода" in user_message:
            weather_info = self.weather_manager.get_weather()
            self.chat_history.insert(tk.END, f"Бот: {weather_info}\n\n")

        elif "включи музыку" in user_message or "включи песню" in user_message:
            if self.music_player.play_random():
                self.chat_history.insert(tk.END, "Бот: Воспроизвожу случайную музыку...\n\n")
            else:
                self.chat_history.insert(tk.END, "Бот: Не найдено музыкальных файлов. Выберите папку с музыкой.\n\n")

        else:
            bot_response = self.neural_network.respond(user_message)
            self.chat_history.insert(tk.END, f"Бот: {bot_response}\n\n")

        self.chat_history.config(state='disabled')
        self.chat_history.see(tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    app = ChatApp(root)
    root.mainloop()
