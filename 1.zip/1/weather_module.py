import sqlite3
import requests
from datetime import datetime, timedelta

class WeatherManager:
    def __init__(self, city="Moscow"):
        self.city = city
        self.db_name = "knowledge.db"
        self.init_db()

    def init_db(self):
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS weather (
                    date TEXT PRIMARY KEY,
                    temp_c REAL,
                    condition TEXT,
                    city TEXT
                )
            ''')
            conn.commit()

    def fetch_weather(self):
        try:
            url = f"https://wttr.in/{self.city}?format=j1"
            response = requests.get(url, timeout=10)
            if response.status_code != 200:
                return False

            data = response.json()
            if not data:
                return False

            with sqlite3.connect(self.db_name) as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM weather")

                for day in range(7):
                    date = (datetime.now() + timedelta(days=day)).strftime("%Y-%m-%d")
                    temp_c = data["forecast"][day]["avgtempC"]
                    condition = data["forecast"][day]["lang_ru"][0]["value"]

                    cursor.execute(
                        "INSERT INTO weather (date, temp_c, condition, city) VALUES (?, ?, ?, ?)",
                        (date, temp_c, condition, self.city)
                    )
                conn.commit()
            return True
        except Exception as e:
            print(f"Ошибка при получении погоды: {e}")
            return False

    def get_weather(self, date=None):
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            if date:
                cursor.execute(
                    "SELECT temp_c, condition FROM weather WHERE date = ?",
                    (date,)
                )
            else:
                cursor.execute(
                    "SELECT date, temp_c, condition FROM weather ORDER BY date ASC LIMIT 7"
                )
            result = cursor.fetchall()
            if not result:
                return "Нет данных о погоде. Попробуйте обновить."

            if date:
                return f"Температура: {result[0][0]}°C, {result[0][1]}."
            else:
                weather_info = ["Погода на неделю:"]
                for record in result:
                    weather_info.append(f"{record[0]}: {record[1]}°C, {record[2]}")
                return "\n".join(weather_info)
